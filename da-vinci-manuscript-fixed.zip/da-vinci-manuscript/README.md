# Da Vinci Manuscript Generator (Organized Build)

This is a cleaned and organized build of your project.

## Structure
- `index.html` — main page
- `styles/style.css` — extracted styles
- `scripts/lib-editor.1754557047.js` — local lib editor bundle
- `scripts/ai-4.3.16.js` — local AI bundle
- `scripts/gtm-i.js` — local GTM script (from i.js)
- `scripts/collect-rangers-v5.2.1.js` — local analytics helper
- External (CDN): `youware-openai-1.3.22.js`, `youware-zod-3.25.67.js`

## Notes
- I converted inline `<style>` into `styles/style.css`.
- Replaced Youware CDN files that you provided locally; kept the ones you did not upload (OpenAI & Zod) via CDN, now loaded with `defer`.
- All local scripts are loaded with `defer` to avoid blocking and fix typical `is not defined` race conditions.

If you prefer fully offline, provide local copies of the remaining CDN files and place them in `scripts/`, then update the `<script>` tags accordingly.
